package com.tracing.server11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Server11Application {

	public static void main(String[] args) {
		SpringApplication.run(Server11Application.class, args);
	}
}
